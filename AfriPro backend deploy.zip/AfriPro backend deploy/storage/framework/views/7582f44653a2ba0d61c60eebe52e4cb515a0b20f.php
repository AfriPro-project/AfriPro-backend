<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/macbook/Desktop/flutterprojects/AfriPro/AfriPro-backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>