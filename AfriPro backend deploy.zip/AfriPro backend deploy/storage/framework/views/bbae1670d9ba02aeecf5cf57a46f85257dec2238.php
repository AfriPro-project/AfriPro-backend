<center><small>&copy 2021</small></center>
<?php /**PATH /Users/macbook/Desktop/flutterprojects/AfriPro/AfriPro-backend/resources/views/components/footer.blade.php ENDPATH**/ ?>