<center>
    <img  src="<?php echo e(URL::asset('images/logo.svg')); ?>"/>
</center>
<?php /**PATH /Users/macbook/Desktop/flutterprojects/AfriPro/AfriPro-backend/resources/views/components/header.blade.php ENDPATH**/ ?>