<style>
    body{
     font-family: 'arial';
    }
</style>
<?php /**PATH /Users/macbook/Desktop/flutterprojects/AfriPro/AfriPro-backend/resources/views/styles/email_styles.blade.php ENDPATH**/ ?>