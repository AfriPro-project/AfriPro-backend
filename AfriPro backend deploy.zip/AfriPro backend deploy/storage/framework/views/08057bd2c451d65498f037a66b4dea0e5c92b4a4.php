<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AfriPro</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/emailVerification.css')); ?>">

</head>
<body>
   <div class="container">
        <div>
            <div class="image">
                <center>
                    <?php if($alert =='success'): ?>
                     <img  src="<?php echo e(URL::asset('images/sucess.svg')); ?>"/>
                    <?php else: ?>
                    <img  src="<?php echo e(URL::asset('images/error.svg')); ?>"/>
                    <?php endif; ?>
                </center>
            </div>
              <div class="message-box"><p class="message"><?php echo e($message); ?><p></div>
            </div>
    </div>
</body>
</html>
<?php /**PATH /Users/macbook/Desktop/flutterprojects/AfriPro/AfriPro-backend/resources/views/email_verification_view.blade.php ENDPATH**/ ?>