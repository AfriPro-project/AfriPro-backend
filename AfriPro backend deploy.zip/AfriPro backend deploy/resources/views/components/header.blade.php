<center>
    <img width="100px"  src="{{ URL::asset('public/images/logo.png') }}"/>
</center>
